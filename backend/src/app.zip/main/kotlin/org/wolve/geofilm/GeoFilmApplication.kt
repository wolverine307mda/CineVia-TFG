package org.wolve.geofilm

import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Value
import org.springframework.boot.ApplicationRunner
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication
import org.springframework.context.annotation.Bean

@SpringBootApplication(
    exclude = [org.springframework.boot.autoconfigure.flyway.FlywayAutoConfiguration::class]
)
class GeoFilmApplication {
    @Value("\${server.port}") private lateinit var serverPort: String
    private val logger = LoggerFactory.getLogger(GeoFilmApplication::class.java)

    /** Solo registra URLs al arrancar */
    @Bean
    fun startupLogger(): ApplicationRunner = ApplicationRunner {
        val urlPort    = "http://localhost:$serverPort"
        val urlSwagger = "$urlPort/swagger-ui/index.html"
        logger.info("🚀 La aplicación está corriendo en: $urlPort")
        logger.info("🔍 Swagger disponible en: $urlSwagger")
    }
}

fun main(args: Array<String>) {
    runApplication<GeoFilmApplication>(*args)
}
