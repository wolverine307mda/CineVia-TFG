package org.wolve.geofilm.config.database

import org.flywaydb.core.Flyway
import org.springframework.boot.ApplicationRunner
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import javax.sql.DataSource

@Configuration
class FlywayConfig {
    @Bean
    @ConditionalOnProperty(prefix = "spring.flyway", name = ["enabled"], havingValue = "true")
    fun flyway(dataSource: DataSource): Flyway =
        Flyway.configure()
            .dataSource(dataSource)
            .locations("classpath:db/migration")
            .baselineOnMigrate(true)
            .load()

    @Bean
    @ConditionalOnProperty(prefix = "spring.flyway", name = ["enabled"], havingValue = "true")
    fun flywayRunner(flyway: Flyway): ApplicationRunner = ApplicationRunner {
        flyway.migrate()
    }
}
