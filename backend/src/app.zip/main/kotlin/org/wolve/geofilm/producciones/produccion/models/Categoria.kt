package org.wolve.geofilm.producciones.produccion.models

enum class Categoria {
    FICCION, AVENTURA, TERROR, COMEDIA, DRAMA, DOCUMENTAL, ANIMACION, ROMANCE, OTROS, CRIMEN, ACCION, CIENCIA_FICCION, FANTASIA, MUSICAL, WESTERN, SUSPENSE
}